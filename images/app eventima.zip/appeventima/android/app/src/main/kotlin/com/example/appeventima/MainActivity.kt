package com.example.appeventima

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
