class Service{
  int id;
  String titre;
  String image;
  int prix;
  String adress;
  String offre;
  String img1;
  String img2;
  String img3;
  String descreption;
  bool isFavorited;
  int favoriteCount;

  Service(this.id,this.titre,this.image,this.img1,this.img2,this.img3,this.prix,this.adress,this.descreption,this.offre,this.isFavorited,this.favoriteCount);
}

